1.Adapter Design Pattern for the database car that use to carList and FavCarList
2.Singleton Pattern for person and person list, paymentInfo and PaymentList
3.Mediator Pattern also for the car to communication medium between different objects in a system. Also we want to keep logging while we are in the system.
4.Observer Pattern that when we want to save the changes in the profile
5.Facade Pattern for each frame 
6.Composite Pattern for each error message in the package (Message)
7.Iterator Pattern for each list that we need to find the information from it.

