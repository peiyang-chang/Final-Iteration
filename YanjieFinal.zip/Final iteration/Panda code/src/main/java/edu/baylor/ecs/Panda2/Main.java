package edu.baylor.ecs.Panda2;

/**
 * <h1>Main</h1> It opens the home page
 * <p>
 *
 * @author Yanjie Ning
 * @version 1.7
 * @since 2019-9-25
 */
public class Main {
	public static void main(String[] args) {
		HomePage hp = new HomePage();
		hp.CreateFrame();
	}
}
